#!/usr/bin/env python3
"""Podglad ekranu PROPAGACJA - styl "gauge" jak w aplikacjach propagacyjnych.

Rysuje ekran 480x320 (skala 3x) w stylu typowych aplikacji propagacyjnych:
- 4 kolowe wskazniki (gauge): SFI, K-index, A-index, SSN
- pasek X-Ray / MUF + ogolna ocena warunkow
- tabela pasm HF z kolorowymi belkami DAY/NIGHT (GOOD/FAIR/POOR)
Kolory 1:1 z RGB565 firmware. Tylko poglad - zadne zmiany w main.cpp.
"""
import math
import sys
from PIL import Image, ImageDraw, ImageFont

W, H = 480, 320
SCALE = 3

def rgb565_to_rgb(v):
    r = (v >> 11) & 0x1F
    g = (v >> 5) & 0x3F
    b = v & 0x1F
    return (r * 255 // 31, g * 255 // 63, b * 255 // 31)

BLK   = rgb565_to_rgb(0x0000)
NAVY  = rgb565_to_rgb(0x0010)
GREEN = rgb565_to_rgb(0x07E0)
DGREEN= rgb565_to_rgb(0x03E0)
YELL  = rgb565_to_rgb(0xFFE0)
ORANGE = rgb565_to_rgb(0xFD20)
RED   = rgb565_to_rgb(0xF800)
WHITE = rgb565_to_rgb(0xFFFF)
LGREY = rgb565_to_rgb(0xAD55)
DARKGREY = rgb565_to_rgb(0x4208)
CARD  = rgb565_to_rgb(0x1082)
CYAN  = rgb565_to_rgb(0x07FF)
GOLD  = rgb565_to_rgb(0xFFE0)
BLUE  = rgb565_to_rgb(0x7E7C)   # jasny niebieski do X-Ray/MUF

try:
    f_num  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 26)
    f_big  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 34)
    f_lbl  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
    f_sml  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    f_tiny = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 9)
except Exception:
    f_num = f_big = f_lbl = f_sml = f_tiny = ImageFont.load_default()

def k_color(kv):
    if kv < 3: return GREEN
    if kv < 5: return YELL
    if kv < 6: return ORANGE
    return RED

def cond_col(c):
    c = c.upper()
    if "GOOD" in c: return GREEN
    if "FAIR" in c: return YELL
    if "POOR" in c: return RED
    return LGREY

def gauge(d, cx, cy, r, frac, col, label, val, vcol):
    """Kolejowy wskaznik: tlo ciemne, luku koloru od -135st do +135st."""
    cx *= SCALE; cy *= SCALE; r *= SCALE
    # obwodka
    d.ellipse([cx - r - 2 * SCALE, cy - r - 2 * SCALE, cx + r + 2 * SCALE, cy + r + 2 * SCALE],
              outline=DARKGREY, width=2 * SCALE)
    # arc tla (stale, slabo widoczny) oraz arc aktywny
    for k in range(1, 19):
        dd = d.arc if hasattr(d, 'arc') else None
    a0 = 45
    a1 = 315
    # pomalowany luk
    span = (a1 - a0) * frac
    d.arc([cx - r, cy - r, cx + r, cy + r], start=a0, end=a0 + span,
          fill=col, width=max(4, 3 * SCALE))
    # tlo luku (reszta) - cienki ciemny
    d.arc([cx - r, cy - r, cx + r, cy + r], start=a0 + span, end=a1,
          fill=(30, 30, 34), width=max(3, 2 * SCALE))
    # wartosc
    d.text((cx, cy - 12 * SCALE), val, fill=vcol, font=f_big, anchor="mm")
    # etykieta
    d.text((cx, cy + 24 * SCALE), label, fill=LGREY, font=f_sml, anchor="mm")


def render(sfi="132", k="3", ssn="189", a="9", xray="M1", muf="21.4",
           updated="04 Nov 08:00", bands=None, out="propagation_preview_gauge.png"):
    if bands is None:
        bands = [("80m-40m", "GOOD", "FAIR"),
                 ("30m-20m", "GOOD", "GOOD"),
                 ("17m-15m", "FAIR", "POOR"),
                 ("12m-10m", "POOR", "POOR")]
    img = Image.new("RGB", (W * SCALE, H * SCALE), BLK)
    d = ImageDraw.Draw(img)

    def txt(x, y, s, col, font, anchor="la"):
        d.text((x * SCALE, y * SCALE), s, fill=col, font=font, anchor=anchor)

    # --- Header (uiHeader) ---
    d.rectangle([0, 0, W * SCALE, 30 * SCALE], fill=GOLD)
    txt(10, 8, "PROPAGACJA", BLK, f_lbl)
    d.rectangle([430 * SCALE, 8 * SCALE, 448 * SCALE, 20 * SCALE], outline=BLK, width=2)
    d.rectangle([450 * SCALE, 8 * SCALE, 468 * SCALE, 20 * SCALE], outline=BLK, width=2)

    # --- 4 wskazniki (y=36..132) ---
    sfi_val = float(sfi)
    k_val = int(k)
    a_val = int(a)
    ssn_val = int(ssn)

    yg = 80   # srodek wskaznikow
    rg = 48   # promien
    xs = [64, 178, 292, 406]

    # SFI skala 60..250
    gauge(d, xs[0], yg, rg, max(0, min(1, (sfi_val - 60) / 190)), GOLD, "SFI", sfi, GOLD)
    # K 0..9
    gauge(d, xs[1], yg, rg, k_val / 9, k_color(k_val), "K-INDEX", str(k_val), k_color(k_val))
    # A 0..50
    gauge(d, xs[2], yg, rg, max(0, min(1, a_val / 50)), CYAN, "A-INDEX", str(a_val), CYAN)
    # SSN 0..250
    gauge(d, xs[3], yg, rg, max(0, min(1, ssn_val / 250)), LGREY, "SSN", str(ssn_val), WHITE)

    # --- Ocena + X-Ray / MUF (y=136..160) ---
    # ogolna ocena na podstawie K i SFI
    if k_val <= 2 and sfi_val >= 120:
        verdict = "DOBRA"
        vcol = GREEN
    elif k_val <= 4 and sfi_val >= 90:
        verdict = "UMIARKOWANA"
        vcol = YELL
    else:
        verdict = "SLABA"
        vcol = RED

    # pasek oceny
    d.rounded_rectangle([10 * SCALE, 140 * SCALE, 250 * SCALE, 158 * SCALE],
                        radius=6 * SCALE, fill=CARD, outline=DARKGREY, width=2)
    txt(20, 142, "WARUNKI:", LGREY, f_sml)
    txt(110, 141, verdict, vcol, f_sml)
    # X-Ray i MUF po prawej
    d.rounded_rectangle([262 * SCALE, 140 * SCALE, 382 * SCALE, 158 * SCALE],
                        radius=6 * SCALE, fill=CARD, outline=DARKGREY, width=2)
    txt(272, 142, "X-Ray " + xray, WHITE, f_sml)
    d.rounded_rectangle([390 * SCALE, 140 * SCALE, 470 * SCALE, 158 * SCALE],
                        radius=6 * SCALE, fill=CARD, outline=DARKGREY, width=2)
    txt(398, 142, "MUF", LGREY, f_sml)
    txt(398, 152, muf + "MHz", WHITE, f_sml)

    # --- Tabela pasm HF (y=164..216) ---
    y2 = 164
    hm = 12
    # naglowki
    txt(18, y2, "HF BAND", WHITE, f_sml)
    txt(170, y2, "DAY", WHITE, f_sml)
    txt(310, y2, "NIGHT", WHITE, f_sml)
    d.line([(12 * SCALE, (y2 + 14) * SCALE), (468 * SCALE, (y2 + 14) * SCALE)], fill=DARKGREY, width=2)

    yy = y2 + 20
    row_h = 10
    for (lbl, day, night) in bands:
        # naprzemienne tlo
        if (yy - y2) // 12 % 2 == 0:
            d.rectangle([8 * SCALE, (yy - 2) * SCALE, 472 * SCALE, (yy + row_h + 1) * SCALE],
                        fill=(10, 12, 14))
        txt(18, yy, lbl, WHITE, f_sml)
        # belka DAY
        dc = cond_col(day)
        # kropka+pasek (styl belki)
        d.rounded_rectangle([162 * SCALE, (yy - 1) * SCALE, 268 * SCALE, (yy + row_h - 1) * SCALE],
                            radius=4 * SCALE, fill=(30, 40, 30) if dc == GREEN else (30, 30, 20) if dc == YELL else (40, 20, 20))
        d.ellipse([(166 * SCALE, (yy + 1) * SCALE), (176 * SCALE, (yy + row_h - 2) * SCALE)], fill=dc)
        d.text((182 * SCALE, (yy + 4) * SCALE), day, fill=dc, font=f_tiny, anchor="lm")
        # belka NIGHT
        nc = cond_col(night)
        d.rounded_rectangle([300 * SCALE, (yy - 1) * SCALE, 460 * SCALE, (yy + row_h - 1) * SCALE],
                            radius=4 * SCALE, fill=(30, 40, 30) if nc == GREEN else (30, 30, 20) if nc == YELL else (40, 20, 20))
        d.ellipse([(304 * SCALE, (yy + 1) * SCALE), (314 * SCALE, (yy + row_h - 2) * SCALE)], fill=nc)
        d.text((320 * SCALE, (yy + 4) * SCALE), night, fill=nc, font=f_tiny, anchor="lm")
        yy += 12

    # --- Footer / nav ---
    d.rectangle([0, 220 * SCALE, W * SCALE, 240 * SCALE], fill=CARD)
    foot_lbl = "UPDATED " + updated
    txt((480 - len(foot_lbl) * 6) // 2, 230, foot_lbl, LGREY, f_sml)

    img = img.resize((W * SCALE, H * SCALE), Image.NEAREST)
    img.save(out)
    print("saved", out)


if __name__ == "__main__":
    variants = {
        "k1_gladkie": dict(k="1", a="5", ssn="210", sfi="168",
                          bands=[("80m-40m","GOOD","GOOD"),("30m-20m","GOOD","GOOD"),
                                 ("17m-15m","GOOD","GOOD"),("12m-10m","GOOD","FAIR")]),
        "k3_normalne": dict(k="3", a="9", ssn="189", sfi="132",
                          bands=[("80m-40m","GOOD","FAIR"),("30m-20m","GOOD","GOOD"),
                                 ("17m-15m","FAIR","POOR"),("12m-10m","POOR","POOR")]),
        "k5_burzowo": dict(k="5", a="22", ssn="120", sfi="98",
                          bands=[("80m-40m","FAIR","POOR"),("30m-20m","FAIR","POOR"),
                                 ("17m-15m","POOR","POOR"),("12m-10m","POOR","POOR")]),
        "k8_burza": dict(k="8", a="47", ssn="74", sfi="83",
                        bands=[("80m-40m","POOR","POOR"),("30m-20m","POOR","POOR"),
                               ("17m-15m","POOR","POOR"),("12m-10m","POOR","POOR")]),
    }
    render(out="propagation_preview_gauge.png")
    for name, vals in variants.items():
        render(out=f"propagation_preview_gauge_{name}.png", **vals)