#!/usr/bin/env python3
"""Podglad ekranu PROPAGACJA - styl "dashboard radiowy" (trzeci kierunek).

Zupełnie inny styl niz karty / gauge:
- gorne kolorowe pasy duzych odczytow (SFI, K, A, SSN) - "cyfrowe" tablicy
- pasek X-Ray / MUF / ocena warunkow na wysokosc
- tabela pasm HF z poziomymi paskami (belki 0-100%) dla DAY i NIGHT
Kolory 1:1 z RGB565 firmware. Tylko podglad.
"""
import sys
from PIL import Image, ImageDraw, ImageFont

W, H = 480, 320
SCALE = 3

def rgb565_to_rgb(v):
    r = (v >> 11) & 0x1F
    g = (v >> 5) & 0x3F
    b = v & 0x1F
    return (r * 255 // 31, g * 255 // 63, b * 255 // 31)

BLK   = rgb565_to_rgb(0x0000)
NAVY  = rgb565_to_rgb(0x0010)
GREEN = rgb565_to_rgb(0x07E0)
YELL  = rgb565_to_rgb(0xFFE0)
ORANGE = rgb565_to_rgb(0xFD20)
RED   = rgb565_to_rgb(0xF800)
WHITE = rgb565_to_rgb(0xFFFF)
LGREY = rgb565_to_rgb(0xAD55)
DARKGREY = rgb565_to_rgb(0x4208)
CARD  = rgb565_to_rgb(0x1082)
CYAN  = rgb565_to_rgb(0x07FF)
GOLD  = rgb565_to_rgb(0xFFE0)

try:
    f_num  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 26)
    f_big  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 30)
    f_lbl  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
    f_sml  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    f_tiny = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 9)
except Exception:
    f_num = f_big = f_lbl = f_sml = f_tiny = ImageFont.load_default()

def k_color(kv):
    if kv < 3: return GREEN
    if kv < 5: return YELL
    if kv < 6: return ORANGE
    return RED

def cond_col(c):
    c = c.upper()
    if "GOOD" in c: return GREEN
    if "FAIR" in c: return YELL
    if "POOR" in c: return RED
    return LGREY

def col_soft(c, amt=0.18):
    return tuple(int(x + (255 - x) * amt) for x in c)

def render(sfi="132", k="3", ssn="189", a="9", xray="M1", muf="21.4",
           updated="04 Nov 08:00", bands=None, out="propagation_preview_dash.png"):
    if bands is None:
        bands = [("80m-40m", "GOOD", "FAIR"),
                 ("30m-20m", "GOOD", "GOOD"),
                 ("17m-15m", "FAIR", "POOR"),
                 ("12m-10m", "POOR", "POOR")]
    img = Image.new("RGB", (W * SCALE, H * SCALE), BLK)
    d = ImageDraw.Draw(img)

    def txt(x, y, s, col, font, anchor="la"):
        d.text((x * SCALE, y * SCALE), s, fill=col, font=font, anchor=anchor)

    # --- Header ---
    d.rectangle([0, 0, W * SCALE, 30 * SCALE], fill=GOLD)
    txt(10, 8, "PROPAGACJA", BLK, f_lbl)
    d.rectangle([430 * SCALE, 8 * SCALE, 448 * SCALE, 20 * SCALE], outline=BLK, width=2)
    d.rectangle([450 * SCALE, 8 * SCALE, 468 * SCALE, 20 * SCALE], outline=BLK, width=2)

    # --- Gorne pasy: SFI, K, A, SSN (y=34..124) ---
    sfi_val = float(sfi)
    k_val = int(k)
    a_val = int(a)
    ssn_val = int(ssn)

    def big_tile(x0, y0, w, h, value, label, vcol, accent):
        pad = 6
        d.rounded_rectangle([(x0) * SCALE, y0 * SCALE, (x0 + w) * SCALE, (y0 + h) * SCALE],
                            radius=6 * SCALE, fill=CARD, outline=vcol, width=2 * SCALE)
        d.rectangle([(x0 + pad) * SCALE, (y0 + pad) * SCALE,
                     (x0 + pad + 10) * SCALE, (y0 + pad + 10) * SCALE], fill=vcol)
        d.text(((x0 + pad + 18) * SCALE, (y0 + pad + 4) * SCALE), label, fill=LGREY, font=f_sml, anchor="lt")
        d.text(((x0 + w // 2) * SCALE, (y0 + h // 2 + 4) * SCALE), value, fill=vcol, font=f_big, anchor="mm")

    # 4 kafle: (8, 240x86), (250, 222x86), potem drugi rzad mniejszych
    big_tile(8,  36, 232, 70, sfi, "SFI", GOLD, GOLD)
    big_tile(248, 36, 224, 70, str(k_val), "K-INDEX", k_color(k_val), k_color(k_val))
    big_tile(8,  114, 232, 56, str(a_val), "A-INDEX", CYAN, CYAN)
    big_tile(248, 114, 224, 56, str(ssn_val), "SSN", WHITE, WHITE)

    # --- Srodek: X-Ray / MUF / ocena (y=172..198) ---
    yc = 176
    if k_val <= 2 and sfi_val >= 120:
        verdict, vcol = "DOBRA", GREEN
    elif k_val <= 4 and sfi_val >= 90:
        verdict, vcol = "UMIARKOWANA", YELL
    else:
        verdict, vcol = "SLABA", RED
    d.rounded_rectangle([8 * SCALE, yc * SCALE, 152 * SCALE, (yc + 22) * SCALE],
                        radius=6 * SCALE, fill=vcol)
    txt(16, yc + 11, "WARUNKI: " + verdict, BLK, f_sml, anchor="lm")
    d.rounded_rectangle([160 * SCALE, yc * SCALE, 312 * SCALE, (yc + 22) * SCALE],
                        radius=6 * SCALE, fill=CARD, outline=DARKGREY, width=2)
    txt(168, yc + 11, "X-Ray " + xray, WHITE, f_sml, anchor="lm")
    d.rounded_rectangle([320 * SCALE, yc * SCALE, 472 * SCALE, (yc + 22) * SCALE],
                        radius=6 * SCALE, fill=CARD, outline=DARKGREY, width=2)
    txt(328, yc + 11, "MUF " + muf + "MHz", WHITE, f_sml, anchor="lm")

    # --- Tabela pasm z poziomymi belkami (y=200..218+) ---
    y2 = 204
    txt(18, y2 - 4, "HF BAND", WHITE, f_sml)
    txt(170, y2 - 4, "DAY", WHITE, f_sml)
    txt(320, y2 - 4, "NIGHT", WHITE, f_sml)
    d.line([(12 * SCALE, (y2 + 8) * SCALE), (468 * SCALE, (y2 + 8) * SCALE)], fill=DARKGREY, width=2)

    yy = y2 + 14
    row_h = 9
    for (lbl, day, night) in bands:
        if (yy - y2) // 12 % 2 == 0:
            d.rectangle([6 * SCALE, (yy - 2) * SCALE, 474 * SCALE, (yy + row_h + 1) * SCALE],
                        fill=(10, 12, 14))
        txt(18, yy, lbl, WHITE, f_sml)
        dc = cond_col(day)
        d.rounded_rectangle([160 * SCALE, (yy - 1) * SCALE, 268 * SCALE, (yy + row_h - 1) * SCALE],
                            radius=4 * SCALE, fill=col_soft(dc, 0.75))
        d.rectangle([160 * SCALE, (yy - 1) * SCALE,
                     (160 + 108 * (1 if day != "POOR" else 0.35)) * SCALE, (yy + row_h - 1) * SCALE],
                    fill=dc)
        d.text((272 * SCALE, (yy + 4) * SCALE), day, fill=dc, font=f_tiny, anchor="lm")
        nc = cond_col(night)
        d.rounded_rectangle([318 * SCALE, (yy - 1) * SCALE, 426 * SCALE, (yy + row_h - 1) * SCALE],
                            radius=4 * SCALE, fill=col_soft(nc, 0.75))
        d.rectangle([318 * SCALE, (yy - 1) * SCALE,
                     (318 + 108 * (1 if night != "POOR" else 0.35)) * SCALE, (yy + row_h - 1) * SCALE],
                    fill=nc)
        d.text((430 * SCALE, (yy + 4) * SCALE), night, fill=nc, font=f_tiny, anchor="lm")
        yy += 12

    # --- Footer ---
    d.rectangle([0, 220 * SCALE, W * SCALE, 240 * SCALE], fill=CARD)
    foot_lbl = "UPDATED " + updated
    txt((480 - len(foot_lbl) * 6) // 2, 230, foot_lbl, LGREY, f_sml)

    img = img.resize((W * SCALE, H * SCALE), Image.NEAREST)
    img.save(out)
    print("saved", out)


if __name__ == "__main__":
    render(out="propagation_preview_dash.png")
    render(out="propagation_preview_dash_k1.png",
           k="1", a="5", ssn="210", sfi="168",
           bands=[("80m-40m","GOOD","GOOD"),("30m-20m","GOOD","GOOD"),
                  ("17m-15m","GOOD","GOOD"),("12m-10m","GOOD","FAIR")])
    render(out="propagation_preview_dash_k8.png",
           k="8", a="47", ssn="74", sfi="83",
           bands=[("80m-40m","POOR","POOR"),("30m-20m","POOR","POOR"),
                  ("17m-15m","POOR","POOR"),("12m-10m","POOR","POOR")])