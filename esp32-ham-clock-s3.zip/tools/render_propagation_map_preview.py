#!/usr/bin/env python3
"""Podglad ekranu PROPAGACJA - mapa propagacji dr2w.de prawie na calym ekranie.

Wg wymagan uzytkownika:
- mapa zajmuje prawie caly ekran (body od 32 do ~268)
- przyciski pasm (80M..10M) na samym dole, dotykowe
- przelacznik regionu: Europe / North America (male u gory mapy)
- gorny pasek z tytulem i wybranym pasmem
Tylko podglad (skala 3x, 480x320).
"""
import sys, os
from PIL import Image, ImageDraw, ImageFont

W, H = 480, 320
SCALE = 3

def rgb565_to_rgb(v):
    r=(v>>11)&0x1F; g=(v>>5)&0x3F; b=v&0x1F
    return (r*255//31, g*255//63, b*255//31)

GOLD = rgb565_to_rgb(0xFFE0)
BLK  = rgb565_to_rgb(0x0000)
WHITE= rgb565_to_rgb(0xFFFF)
LGREY= rgb565_to_rgb(0xAD55)
CARD = rgb565_to_rgb(0x1082)
CYAN = rgb565_to_rgb(0x07FF)
RED  = rgb565_to_rgb(0xF800)
GREEN= rgb565_to_rgb(0x07E0)
BLUE = rgb565_to_rgb(0x001F)

try:
    f_lbl = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
    f_btn = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12)
    f_sml = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
except Exception:
    f_lbl=f_btn=f_sml=ImageFont.load_default()

BANDS = ["80M","40M","30M","20M","17M","15M","12M","10M"]
REGIONS = ["europe","n-america","africa","s-america","asia","australia"]
REGION_SHORT = {"europe":"EU","n-america":"NA","africa":"AF","s-america":"SA","asia":"AS","australia":"OC"}
REGION_FULL = {"europe":"EUROPE","n-america":"N. AMERICA","africa":"AFRICA","s-america":"S. AMERICA","asia":"ASIA","australia":"OCEANIA"}

def render(map_img, active_band="40M", region="europe", out="out.png", updated="04 Nov 08:00"):
    img = Image.new("RGB", (W*SCALE, H*SCALE), BLK)
    d = ImageDraw.Draw(img)
    def txt(x,y,s,col,font,anchor="la"):
        d.text((x*SCALE,y*SCALE),s,fill=col,font=font,anchor=anchor)

    # --- Header (32px) ---
    d.rectangle([0,0,W*SCALE,30*SCALE], fill=GOLD)
    txt(10,8,"PROPAGACJA "+active_band, BLK, f_lbl)
    txt(470,8,REGION_FULL[region], BLK, f_lbl, anchor="ra")

    # --- Mapa: prawie caly ekran (32..250) ---
    top = 34
    bot = 250
    draw_h = bot - top
    draw_w = W
    mw, mh = map_img.size
    scale = max(draw_w/mw, draw_h/mh)
    nm = map_img.resize((max(1,int(round(mw*scale))), max(1,int(round(mh*scale)))), Image.LANCZOS)
    nw, nh = nm.size
    cx0 = (nw - draw_w)//2
    cx1 = cx0 + draw_w
    cy0 = (nh - draw_h)//2
    cy1 = cy0 + draw_h
    crop = nm.crop((max(0,cx0), max(0,cy0), min(nw,cx1), min(nh,cy1)))
    crop = crop.resize((draw_w*SCALE, draw_h*SCALE), Image.NEAREST)
    img.paste(crop, (0, top*SCALE))
    d.rectangle([0, 0, W*SCALE, (top)*SCALE], fill=BLK)
    d.rectangle([0, (bot)*SCALE, W*SCALE, H*SCALE], fill=BLK)

    # --- pasek regionow (y 252..264) ---
    ry = 252
    rh = 12
    gap = 3
    total_r = len(REGIONS)
    rw = (W - 8 - gap*(total_r-1)) // total_r
    for i,reg in enumerate(REGIONS):
        rx = 4 + i*(rw+gap)
        active = (reg==region)
        if active:
            d.rounded_rectangle([rx*SCALE, ry*SCALE, (rx+rw)*SCALE, (ry+rh)*SCALE],
                                radius=2*SCALE, fill=CYAN, outline=WHITE, width=2)
            txt(rx+rw//2, ry+rh//2, REGION_SHORT[reg], BLK, f_btn, anchor="mm")
        else:
            d.rounded_rectangle([rx*SCALE, ry*SCALE, (rx+rw)*SCALE, (ry+rh)*SCALE],
                                radius=2*SCALE, fill=CARD, outline=(65,65,65), width=1)
            txt(rx+rw//2, ry+rh//2, REGION_SHORT[reg], LGREY, f_btn, anchor="mm")

    # --- przyciski pasm (na dole y 268..280) ---
    by = 268
    bh = 12
    gap = 3
    total = len(BANDS)
    bwidth = (W - 8 - gap*(total-1)) // total
    for i,b in enumerate(BANDS):
        bx = 4 + i*(bwidth+gap)
        if b==active_band:
            d.rounded_rectangle([bx*SCALE, by*SCALE, (bx+bwidth)*SCALE, (by+bh)*SCALE],
                                radius=2*SCALE, fill=CYAN, outline=WHITE, width=2)
            txt(bx+bwidth//2, by+bh//2, b, BLK, f_btn, anchor="mm")
        else:
            d.rounded_rectangle([bx*SCALE, by*SCALE, (bx+bwidth)*SCALE, (by+bh)*SCALE],
                                radius=2*SCALE, fill=CARD, outline=(65,65,65), width=1)
            txt(bx+bwidth//2, by+bh//2, b, LGREY, f_btn, anchor="mm")

    # --- footer---
    d.rectangle([0, 284*SCALE, W*SCALE, 320*SCALE], fill=BLK)
    foot = "UPDATED "+updated+"   •   pasmo/region dotknij"
    txt((W - len(foot)*6)//2, 292, foot, LGREY, f_sml)

    img = img.resize((W*SCALE, H*SCALE), Image.NEAREST)
    img.save(out)
    print("saved", out)

if __name__ == "__main__":
    # podglady: wszystkie 6 regionow dla 20M i 40M
    for reg in REGIONS:
        for b in ["20M","40M"]:
            m = Image.open(f"dr2w_{reg}_{b}_12.png").convert("RGB")
            render(m, active_band=b, region=reg, out=f"propagation_preview_map_{reg}_{b}.png")
    # glowne podglady do galerii (Europe 40M domyslny)
    render(Image.open("dr2w_europe_40M_12.png").convert("RGB"), active_band="40M", region="europe",
           out="propagation_preview_map_default.png")