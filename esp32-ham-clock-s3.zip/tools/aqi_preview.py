#!/usr/bin/env python3
"""Symulacja panelu AQI na ekranie pogody (480x320, RGB565) - podglad przed wdrozeniem."""
import math
from PIL import Image, ImageDraw, ImageFont

W, H = 480, 320
SCALE = 3  # zoom do podgladu

def rgb565_to_rgb(v):
    r = (v >> 11) & 0x1F
    g = (v >> 5) & 0x3F
    b = v & 0x1F
    return (r * 255 // 31, g * 255 // 63, b * 255 // 31)

# kolory zgodne z firmware (RGB565 dokladnie)
GREEN  = 0x07E0
YELLOW = 0xFFE0
ORANGE = 0xFD20
RED    = 0xF800
DRED   = 0xF800
WHITE  = 0xFFFF
GREY   = 0x8410
LGREY  = 0xAD55
DARK   = 0x1082
BLK    = 0x0000
ACCENT = 0x3697

def pm25_color(pm):
    if pm <= 12: return GREEN
    if pm <= 35: return YELLOW
    if pm <= 55: return ORANGE
    if pm <= 150: return RED
    return RED

def pm25_index(pm):
    # AQI-like, 0..~200
    if pm <= 12:   return round(pm / 12 * 50)
    if pm <= 35:   return round(50 + (pm - 12) / 23 * 50)
    if pm <= 55:   return round(100 + (pm - 35) / 20 * 50)
    if pm <= 150:  return round(150 + (pm - 55) / 95 * 50)
    return 200

def pm25_label(pm):
    if pm <= 12: return "DOBRA"
    if pm <= 35: return "UMIARK."
    if pm <= 55: return "NIEZDROWA"
    return "SZKODLIWA"

def render(pm25, path):
    img = Image.new("RGB", (W * SCALE, H * SCALE))
    d = ImageDraw.Draw(img)
    # uproszczony font mono - uzyjemy podstawowego bitmap
    f_big   = ImageFont.load_default()
    # przy S=3 default font jest za maly - uzyjemy fontu truetype jesli dostepny
    try:
        f_num = ImageFont.truetype("DejaVuSansMono-Bold.ttf", int(11 * SCALE))
    except Exception:
        f_num = ImageFont.load_default()
    try:
        f_lbl = ImageFont.truetype("DejaVuSansMono.ttf", int(8 * SCALE))
    except Exception:
        f_lbl = ImageFont.load_default()

    def px(x, y, c):
        d.rectangle([x * SCALE, y * SCALE, (x + 1) * SCALE - 1, (y + 1) * SCALE - 1], fill=c)

    def txt(x, y, s, c, f=None, anchor=None):
        d.text((x * SCALE, y * SCALE), s, font=f or f_lbl, fill=c)

    # ---- tlo ekranu (symulacja) ----
    d.rectangle([0, 0, W * SCALE, H * SCALE], fill=rgb565_to_rgb(BLK))
    # header
    d.rectangle([0, 0, W * SCALE, 30 * SCALE], fill=rgb565_to_rgb(0x0884))
    d.rectangle([0, 29 * SCALE, W * SCALE, 30 * SCALE], fill=rgb565_to_rgb(ORANGE))
    txt(8, 10, "POGODA", rgb565_to_rgb(WHITE), f_lbl)
    # body (atrapa)
    d.rectangle([0, 32 * SCALE, W * SCALE, 215 * SCALE], fill=rgb565_to_rgb(0x10507c))
    txt(20, 55 * SCALE, "temperatura / wilgotnosc / wiatr / cisnienie...", rgb565_to_rgb(WHITE), f_lbl)

# ---- PANEL AQI (wiersz y=221..229; lokalizacja zostaje na y=230) ----
    # Wszystko miesci sie w oryginalnym 20px pasku footera, bez ruszania reszty ekranu.
    pm = min(max(pm25, 0), 200)
    col = pm25_color(pm)
    aqi = pm25_index(pm)
    label = pm25_label(pm)
    frac = max(0, min(1, pm / 200.0))

    # 1. Malutka kolorowa ikonka (pusty krag + wypelniony) - jak "kropka jakosci"
    cx, cy, r = 12, 225, 4
    d.ellipse([(cx - r) * SCALE, (cy - r) * SCALE, (cx + r) * SCALE, (cy + r) * SCALE], outline=rgb565_to_rgb(LGREY), width=1)
    d.ellipse([(cx - r + 1) * SCALE, (cy - r + 1) * SCALE, (cx + r - 1) * SCALE, (cy + r - 1) * SCALE], fill=rgb565_to_rgb(col))

    # 2. "AQI" bialy + wartosc + etykieta w kolorze
    txt(22, py_off := 221, "AQI", rgb565_to_rgb(LGREY), f_lbl)
    txt(52, py_off, str(aqi), rgb565_to_rgb(WHITE), f_lbl)
    txt(78, py_off, label, rgb565_to_rgb(col), f_lbl)

    # 3. Gradientowy pasek skali
    bx, by, bw, bh = 148, 223, 160, 4
    for i in range(bw):
        t = i / bw
        if t < 0.25:   c = GREEN
        elif t < 0.5:  c = YELLOW
        elif t < 0.75: c = ORANGE
        else:          c = RED
        d.rectangle([(bx + i) * SCALE, by * SCALE, (bx + i + 1) * SCALE - 1, (by + bh) * SCALE], fill=rgb565_to_rgb(c))
    # znacznik aktualnej pozycji (biala kreska)
    if 0 <= frac <= 1:
        d.rectangle([(bx + bw * frac) * SCALE, (by - 2) * SCALE, (bx + bw * frac + 2) * SCALE, (by + bh + 1) * SCALE], fill=rgb565_to_rgb(WHITE))

    # 4. PM2.5 / PM10 po prawej
    pm10 = pm * 1.6
    txt(322, py_off, "PM2.5:%d" % pm, rgb565_to_rgb(pm25_color(pm)), f_lbl)
    txt(408, py_off, "PM10:%d" % round(pm10), rgb565_to_rgb(pm25_color(min(pm10, 200))), f_lbl)

    # stopka (lokacja) - NIE ruszamy: zostaje na y=230 jak w firmware
    lbl = "Pogoda dla lokalizacji: WARSZAWA"
    wpx = len(lbl) * 6
    txt((480 - wpx) // 2, 230, lbl, rgb565_to_rgb(0x52AA), f_lbl)

    img = img.resize((W * SCALE, H * SCALE), Image.NEAREST)
    img.save(path)
    print("saved", path, "pm25=", pm)

if __name__ == "__main__":
    for pm in (5, 22, 44, 90, 150):
        render(pm, "aqi_preview_pm%d.png" % pm)
    render(22, "aqi_preview.png")