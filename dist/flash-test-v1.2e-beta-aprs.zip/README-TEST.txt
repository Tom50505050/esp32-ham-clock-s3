ESP32-HAM-CLOCK S3 - paczka testowa (lokalnie, BEZ push na GitHub)
Data: 08.11.2026  (v1.2e-beta + poprawki + APRS settings + sleep clock)

Co nowego:
 - APRS menu/radar: osobne wylaczniki BUZZER i LED (wczesniej polaczone 'LED / Buzzer')
 - APRS menu/radar: toggle 'WX Alert (weather)' - powiadomienia ze stacji pogodowych APRS
 - APRS menu/radar: suwak ALERT_Distance dla stacji ruchomych 0.1 - 500 km
 - Web (config page): osobny checkbox 'Buzzer alert wlaczony' + zakres dystansu 0.1-500 km
 - Ekran uspienia: widoczny na srodku ekranu ladny zegar (delikatne podswietlenie 3%)

SHA256 (merged-flash.bin): 5e6b70b05d8c315bf579b3c71277ab46202a98bbc48d185800b7aa9f4330ed19
SHA256 (merged-flash-notouch.bin): d0381d93c2a70c7e471056baf503f3cf048497bb2891dce53ae9f216dda0668f
